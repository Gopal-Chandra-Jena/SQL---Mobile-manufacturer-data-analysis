--SQL Advance Case Study
USE db_SQLCaseStudies

SELECT *   from DIM_MANUFACTURER
SELECT * from DIM_MODEL
SELECT * from DIM_CUSTOMER
SELECT * from DIM_LOCATION
SELECT  * from DIM_DATE
SELECT * from FACT_TRANSACTIONS

--Q1--BEGIN (List all the states in which we have customers who have bought cellphones from 2005 till today.)

SELECT DISTINCT T1.State from 
DIM_LOCATION T1 INNER JOIN 	FACT_TRANSACTIONS T2
ON T1.IDLocation = T2.IDLocation
WHERE T2.Date> '2005-01-01' ; 





--Q1--END

--Q2--BEGIN (2.	What state in the US is buying the most 'Samsung' cell phones?)
	
SELECT TOP 1 T4.State , SUM(T3.Quantity) TOTAL_QTY FROM 
DIM_MANUFACTURER T1  INNER JOIN DIM_MODEL T2
ON T1.IDManufacturer = T2.IDManufacturer INNER JOIN 
FACT_TRANSACTIONS T3 ON T2.IDModel = T3.IDModel INNER JOIN 
DIM_LOCATION T4 ON T3.IDLocation = T4.IDLocation
WHERE T4.Country = 'US' AND T1.Manufacturer_Name= 'Samsung'
GROUP BY T4.State
ORDER BY SUM(T3.Quantity) DESC; 

--ARIZONA



--Q2--END

--Q3--BEGIN(3.Show the number of transactions for each model per zip code per state.)     
	
	SELECT  T2.State , T2.ZipCode , T3.Model_Name , COUNT(T3.Model_Name) NO_TRANSACTION FROM 
	FACT_TRANSACTIONS T1 INNER JOIN DIM_LOCATION T2 
	ON T1.IDLocation = T2.IDLocation INNER JOIN DIM_MODEL T3 
	ON T1.IDModel = T3.IDModel 
	GROUP BY T2.State , T2.ZipCode , T3.Model_Name ; 




--Q3--END

--Q4--BEGIN(4.Show the cheapest cellphone (Output should contain the price also))

SELECT TOP 1 Model_Name , Unit_price
FROM DIM_MODEL
ORDER BY Unit_price ;





--Q4--END

--Q5--BEGIN(5.Find out the average price for each model in the top5 manufacturers in terms of sales quantity and order by average price.)


create view Q_5 as(
    select top 5  Manufacturer_Name from
	DIM_LOCATION d LEFT JOIN FACT_TRANSACTIONS f on d.IDLocation=f.IDLocation
	RIGHT JOIN DIM_MODEL e ON e.IDModel=f.IDModel RIGHT JOIN DIM_MANUFACTURER m ON m.IDManufacturer= e.IDManufacturer
	group by Manufacturer_Name
	order by sum(Quantity) desc )
select m.Manufacturer_Name,Model_Name,AVG(TotalPrice) [Avg Price] from
	DIM_LOCATION d LEFT JOIN FACT_TRANSACTIONS f on d.IDLocation=f.IDLocation
	RIGHT JOIN DIM_MODEL e ON e.IDModel=f.IDModel RIGHT JOIN DIM_MANUFACTURER m ON m.IDManufacturer= e.IDManufacturer inner join Q_5 q on m.Manufacturer_Name= q.Manufacturer_Name
	group by Model_Name ,m.Manufacturer_Name
	order by�AVG(TotalPrice)




--Q5--END

--Q6--BEGIN (6.List the names of the customers and the average amount spent in 2009, where the average is higher than 500)

SELECT T1.Customer_Name , AVG(T2.TotalPrice) AVG_SPEND FROM 
DIM_CUSTOMER T1 INNER JOIN  FACT_TRANSACTIONS T2
ON T1.IDCustomer = T2.IDCustomer
WHERE Date BETWEEN '2009-1-1' AND '2009-12-31' 
GROUP BY T1.Customer_Name
HAVING AVG(T2.TotalPrice) > 500 ; 
 



--Q6--END
	
--Q7--BEGIN (7.List if there is any model that was in the top 5 in terms of quantity, simultaneously in 2008, 2009 and 2010) 

SELECT Model_Name FROM 	
(SELECT TOP 5 T1.Model_Name , SUM(T2.Quantity) TOTAL_QTY , YEAR(T2.DATE) TRANS_YEAR FROM 
DIM_MODEL T1 INNER JOIN FACT_TRANSACTIONS T2 
ON T1.IDModel = T2.IDModel
GROUP BY  T1.Model_Name ,  YEAR(T2.DATE) 
HAVING  YEAR(T2.DATE) = 2008 
ORDER BY SUM(T2.Quantity) DESC ) AS D1
INTERSECT
SELECT Model_Name FROM 
(SELECT TOP 5  T1.Model_Name , SUM(T2.Quantity) TOTAL_QTY , YEAR(T2.DATE) TRANS_YEAR FROM 
DIM_MODEL T1 INNER JOIN FACT_TRANSACTIONS T2 
ON T1.IDModel = T2.IDModel
GROUP BY  T1.Model_Name ,  YEAR(T2.DATE) 
HAVING  YEAR(T2.DATE) = 2009
ORDER BY SUM(T2.Quantity) DESC) AS D2
INTERSECT 
SELECT Model_Name FROM 
(SELECT TOP 5 T1.Model_Name , SUM(T2.Quantity) TOTAL_QTY , YEAR(T2.DATE) TRANS_YEAR FROM 
DIM_MODEL T1 INNER JOIN FACT_TRANSACTIONS T2 
ON T1.IDModel = T2.IDModel
GROUP BY  T1.Model_Name ,  YEAR(T2.DATE) 
HAVING  YEAR(T2.DATE) = 2010 
ORDER BY SUM(T2.Quantity) DESC ) AS D3 


--Q7--END	
--Q8--BEGIN(8.Show the manufacturer with the 2nd top sales in the year of 2009 and the manufacturer with the 2nd top sales in the year of 2010.)
create view Q_8_1 AS (
    SELECT Manufacturer_Name ,[YEAR], SUM(TotalPrice)[TOTAL SALE] from 
    FACT_TRANSACTIONS f RIGHT JOIN DIM_MODEL e ON e.IDModel=f.IDModel RIGHT JOIN DIM_MANUFACTURER m ON m.IDManufacturer= e.IDManufacturer  RIGHT JOIN DIM_DATE a ON a.DATE=f.Date
	where [YEAR] = 2009
	group by Manufacturer_Name,[YEAR]
	order by sum(TotalPrice) 
   offset 3 rows
   fetch next 1 row only)
	CREATE VIEW Q_8_2 AS (
	SELECT  Manufacturer_Name ,[YEAR], SUM(TotalPrice)[TT] from 
    FACT_TRANSACTIONS f RIGHT JOIN DIM_MODEL e ON e.IDModel=f.IDModel RIGHT JOIN DIM_MANUFACTURER m ON m.IDManufacturer= e.IDManufacturer  RIGHT JOIN DIM_DATE a ON a.DATE=f.Date
	where [YEAR] = 2010
	group by Manufacturer_Name,[YEAR]
	order by sum(TotalPrice) 
	offset 4 rows
	fetch next 1 row only)
	SELECT * FROM Q_8_1 UNION ALL SELECT�*�FROM�Q_8_2 
 

--Q8--END
--Q9--BEGIN (9.Show the manufacturers that sold cellphones in 2010 but did not in 2009.)
SELECT T1.Manufacturer_Name  FROM 
DIM_MANUFACTURER T1 INNER JOIN DIM_MODEL T2 
ON T1.IDManufacturer = T2.IDManufacturer INNER JOIN 
FACT_TRANSACTIONS T3 
ON T2.IDModel = T3.IDModel
WHERE YEAR(T3.Date) = 2010
GROUP BY T1.Manufacturer_Name  
EXCEPT 
SELECT T1.Manufacturer_Name FROM 
DIM_MANUFACTURER T1 INNER JOIN DIM_MODEL T2 
ON T1.IDManufacturer = T2.IDManufacturer INNER JOIN 
FACT_TRANSACTIONS T3 
ON T2.IDModel = T3.IDModel
WHERE YEAR(T3.Date) = 2009  
GROUP BY T1.Manufacturer_Name ;

--Q9--END

--Q10--BEGIN

WITH  CTE1 as (
	SELECT   Customer_Name,[YEAR],AVG(TotalPrice)[Average Spend],AVG(Quantity) [Average Quantity],sum(TotalPrice)[Total_Price]
	FROM 	DIM_CUSTOMER d LEFT JOIN FACT_TRANSACTIONS f on d.IDCustomer=f.IDCustomer  RIGHT JOIN DIM_DATE a ON a.DATE=f.Date
	group by [YEAR],Customer_Name )
	
	SELECT TOP 100 *, (([Total_Price]-lag([Total_Price],1)over (partition by [Customer_Name] ORDER by [YEAR] ,[Customer_Name]) )/lag([Total_Price],1)over (partition by [Customer_Name] ORDER by [YEAR] ,[Customer_Name] )) [Percentage of change in their Spend]
	FROM CTE1
	ORDER BY Customer_Name,[YEAR]

--Q10--END
	